<div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 footer-copyright">
                        
                    </div>
                    <div class="col-md-6">
                        
                    </div>
                </div>
            </div><?php /**PATH C:\xampp\htdocs\ammlok_git\resources\views/seller/layout/footer.blade.php ENDPATH**/ ?>