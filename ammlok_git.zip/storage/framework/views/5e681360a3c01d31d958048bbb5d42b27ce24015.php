
        <!-- Page Sidebar Start-->
        <div class="page-sidebar">

            <div class="sidebar custom-scrollbar">
                <div class="sidebar-user text-center">
                    <div><img class="img-60 rounded-circle" src="<?php echo e(asset('seller/images/dashboard/man.png')); ?>" alt="#">
                    </div>
                    <h6 class="mt-3 f-14"><?php echo e(auth()->user()->name); ?></h6>
                </div>
                <ul class="sidebar-menu">
                    <li><a class="sidebar-header" href="<?php echo e(route('home')); ?>"><i data-feather="home"></i><span>Dashboard</span></a></li>
                    <li><a class="sidebar-header" href="#"><i data-feather="box"></i> <span>Filters</span></a>
                        <ul class="sidebar-submenu">
                            <li><a class="sidebar-header" href="<?php echo e(route('gender.index')); ?>"><i data-feather="home"></i><span>Gender</span></a></li>
                            <li><a class="sidebar-header" href="<?php echo e(route('brand.index')); ?>"><i data-feather="home"></i><span>Brand</span></a></li>
                            <li><a class="sidebar-header" href="<?php echo e(route('color.index')); ?>"><i data-feather="home"></i><span>Color</span></a></li>
                            <li><a class="sidebar-header" href="<?php echo e(route('size.index')); ?>"><i data-feather="home"></i><span>Size</span></a></li>
                            <li><a class="sidebar-header" href="<?php echo e(route('category.index')); ?>"><i data-feather="home"></i><span>Category</span></a></li>
                            <li><a class="sidebar-header" href="<?php echo e(route('sub-category.index')); ?>"><i data-feather="home"></i><span>Sub Category</span></a></li>
                        </ul>
                    </li>
                    <li><a class="sidebar-header" href="#"><i data-feather="box"></i> <span>Products</span></a>
                        <ul class="sidebar-submenu">
                            <li><a class="sidebar-header" href="<?php echo e(route('active.product')); ?>"><i data-feather="home"></i><span>Active Products</span></a></li>
                            <li><a class="sidebar-header" href="<?php echo e(route('retired.product')); ?>"><i data-feather="home"></i><span>Retired Products</span></a></li>
                            <li><a class="sidebar-header" href="<?php echo e(route('product')); ?>"><i data-feather="home"></i><span>Add Product</span></a></li>
                            <li><a class="sidebar-header" href="#"><i data-feather="box"></i> <span>Products</span><i class="fa fa-angle-right pull-right"></i></a>
                        </ul>
                    </li>
                    
                </ul>
            </div>
        </div>
        <!-- Page Sidebar Ends-->

        <!-- Right sidebar Start-->
        
        <!-- Right sidebar Ends-->
<?php /**PATH E:\xampp\htdocs\ammlok_git\resources\views/seller/layout/sidebar.blade.php ENDPATH**/ ?>