<div class="notification">
    <div class="alert <?php echo e($class ?? ''); ?> text-white alert-dismissible" role="alert">
      <?php echo e($message); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
      </button>
    </div>
    </div>
    
    <?php $__env->startPush('styles'); ?>
      <style media="screen">
      .notification {
        position: fixed;
        bottom: 12px;
        right:-300px;
        z-index: 9999;
      }
      </style>
    <?php $__env->stopPush(); ?>
    
<?php /**PATH C:\xampp\htdocs\ammlok_git\resources\views/components/notify-msg.blade.php ENDPATH**/ ?>