<?php $__env->startSection('content'); ?>
	<!-- Container-fluid starts-->
            <div class="container-fluid">
                <div class="page-header">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="page-header-left">
                                <h3>Product List
                                    <small>Multikart Admin panel</small>
                                </h3>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <ol class="breadcrumb pull-right">
                                <li class="breadcrumb-item"><a href="index.html"><i data-feather="home"></i></a></li>
                                <li class="breadcrumb-item">Physical</li>
                                <li class="breadcrumb-item active">Product List</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Container-fluid Ends-->

            <!-- Container-fluid starts-->
            <div class="container-fluid">
                <div class="row products-admin ratio_asos">
                	<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-xl-3 col-sm-6">
                        <div class="card">
                            <div class="card-body product-box">
                                <div class="img-wrapper">
                                    <div class="front">
                                        <a href="#"><img src="<?php echo e(url('../storage/app/public/'.$product->primary_image)); ?>" class="img-fluid blur-up lazyload bg-img" alt=""></a>
                                    </div>
                                </div>
                                <div class="product-detail">
                                </br>
                                    <a href="<?php echo e(route('product.detail', ['product' =>$product])); ?>">
                                        <h6><?php echo e($product->title); ?></h6>
                                    </a>
                                    <h4>Rs.<?php echo e($product->selling_price); ?>  <del>  <?php echo e($product->mrp); ?></del></h4>
                                </br>
                                <h6 class="">Status :
                                    <?php if($product->status == 0): ?>
                                    <span class="text-danger">Retired</span>
                                    <?php else: ?>
                                    Active
                                    <?php endif; ?>
                                </h6>
                                <p><a href="<?php echo e(route('edit.product', ['product' => $product])); ?>" class="btn btn-secondary">Edit</a></p>
                                    <form action="<?php echo e(route('status.product', ['status' => $product->status, 'product' => $product])); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn <?php echo e($product->status == 1 ? 'btn-primary' : 'btn-danger'); ?>"><?php echo e($product->status == 0 ? 'Activate' : 'Retire'); ?></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h1>No data Available.</h1>
                    <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Container-fluid Ends-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('seller.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ammlok_git\resources\views/seller/dashboard/product-list.blade.php ENDPATH**/ ?>