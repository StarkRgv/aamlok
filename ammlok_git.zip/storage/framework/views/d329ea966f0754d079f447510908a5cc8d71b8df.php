<?php $__env->startSection('content'); ?>
<!-- Container-fluid starts-->
<div class="container-fluid">
    <div class="page-header">
        <div class="row">
            <div class="col-lg-6">
                <div class="page-header-left">
                    <h3>Category
                        <small>Multikart Admin panel</small>
                    </h3>
                </div>
            </div>
            <div class="col-lg-6">
                <ol class="breadcrumb pull-right">
                    <li class="breadcrumb-item"><a href="index.html"><i data-feather="home"></i></a></li>
                    <li class="breadcrumb-item">Physical</li>
                    <li class="breadcrumb-item active">Category</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<!-- Container-fluid Ends-->
<?php $__env->startSection('content'); ?>
<?php if(session()->has('success')): ?>
  <?php $__env->startComponent('components.notify-msg', ['class' => 'bg-success']); ?>
    <?php $__env->slot('message'); ?>
      <?php echo e(session('success')); ?>

    <?php $__env->endSlot(); ?>
  <?php if (isset($__componentOriginal3b23374633e9204206f96e8eed6cc0282ffba03f)): ?>
<?php $component = $__componentOriginal3b23374633e9204206f96e8eed6cc0282ffba03f; ?>
<?php unset($__componentOriginal3b23374633e9204206f96e8eed6cc0282ffba03f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if(session()->has('failure')): ?>
  <?php $__env->startComponent('components.notify-msg', ['class' => 'bg-danger']); ?>
    <?php $__env->slot('message'); ?>
      <?php echo e(session('failure')); ?>

    <?php $__env->endSlot(); ?>
  <?php if (isset($__componentOriginal3b23374633e9204206f96e8eed6cc0282ffba03f)): ?>
<?php $component = $__componentOriginal3b23374633e9204206f96e8eed6cc0282ffba03f; ?>
<?php unset($__componentOriginal3b23374633e9204206f96e8eed6cc0282ffba03f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<!-- Container-fluid starts-->
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            

            <div class="card">
                <div class="card-header">
                    <h5>Add Product Variation Images</h5>
                    <a href="<?php echo e(route('product.variation', ['product' => $product->id ])); ?>" class="pull-right btn btn-primary ml-3">Variation <i class="fa fa-pencil" aria-hidden="true"></i></a>
                    <a href="<?php echo e(route('edit.product', ['product' => $product])); ?>" class="pull-right btn btn-primary">Product <i class="fa fa-pencil" aria-hidden="true"></i></a>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $uniqueColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form action="<?php echo e(route('store.variaion.images', ['product' => $product])); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <h4><?php echo e($color->colors->color); ?></h4>
                        <div class="row mt-3">
                            <div class="col-xl-5 col-sm-5 ">
                                <div class="input-group mb-3 row">
                                    <div class="pl-3 custom-file">
                                        <input type="file" class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="image[]" multiple>
                                        <input type="hidden" name="color_id" value="<?php echo e($color->color); ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-7 col-sm-7 ">
                                <?php $__currentLoopData = $variationImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($color->color == $v_image->color_id): ?>
                                <div class="pull-right">
                                    <img class="ml-2" style="height: 5rem" src="<?php echo e(url('../storage/app/public/'.$v_image->file_path)); ?>"alt="<?php echo e($v_image->file_name); ?>">
                                        <p class="text-center mt-1"><a href="<?php echo e(route('destroy.image', ['image' => $v_image])); ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash" aria-hidden="true"></i></a></p>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <hr>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('seller/js/jquery-3.3.1.min.js')); ?>"></script>
<script>
$(".notification").animate({right: '40px'});
          setTimeout(function(){
          $('.notification').slideUp(1000)}, 2500);
</script>
<!-- Container-fluid Ends-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('seller.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\ammlok_git\resources\views/seller/dashboard/add-product-images.blade.php ENDPATH**/ ?>