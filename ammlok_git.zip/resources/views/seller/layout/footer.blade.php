<div class="container-fluid">
                <div class="row">
                    <div class="col-md-6 footer-copyright">
                        
                    </div>
                    <div class="col-md-6">
                        
                    </div>
                </div>
            </div>